# Sample Project


Here is a list of features using for this sample.

Onion Architecture

> Entity Framework Core

> .NET Core 5.0

> Swagger

> CQRS -  Mediator Pattern using MediatR Library

> Repository Pattern

> Postgres

> Unit Of Work 

> Blazor

> WebApi

