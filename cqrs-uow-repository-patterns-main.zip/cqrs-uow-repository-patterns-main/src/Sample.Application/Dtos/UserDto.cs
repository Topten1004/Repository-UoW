namespace Sample.Application.Dtos
{
    public class UserDto
    {
        
    }
}