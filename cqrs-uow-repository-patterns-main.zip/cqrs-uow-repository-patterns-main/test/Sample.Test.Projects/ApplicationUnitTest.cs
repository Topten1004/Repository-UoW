using Xunit;

namespace TestProject1
{
    public class ApplicationUnitTest
    {
        [Fact]
        public void Test1()
        {
        }
    }
}