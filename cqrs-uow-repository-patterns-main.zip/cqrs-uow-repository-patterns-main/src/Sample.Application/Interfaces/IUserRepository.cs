using Sample.Domain.Entities;

namespace Sample.Application.Interfaces
{
    public interface IUserRepository : IRepositoryBase<User>
    {
    }
}